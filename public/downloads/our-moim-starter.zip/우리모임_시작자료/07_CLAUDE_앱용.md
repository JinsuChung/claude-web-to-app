﻿# 작업 규칙 (우리 모임 앱, Expo)

- 나는 코딩을 처음 배우는 사람이다. 설명은 쉬운 한국어로.
- Expo(React Native) + Expo Router 를 쓴다. 새 패키지는 `npx expo install` 로 설치해 줘.
- 데이터는 웹앱과 같은 Supabase 프로젝트를 쓴다. 앱에는 공개(anon) 키만 넣고, 비밀(service_role) 키는 절대 넣지 않는다.
- 공개 키도 EXPO_PUBLIC_ 로 시작하는 환경변수(.env)로 둔다.
- 글자는 크게, 누르는 버튼은 최소 44pt.
- 바꾼 뒤에는 Expo Go에서 확인하는 방법을 알려 줘.
